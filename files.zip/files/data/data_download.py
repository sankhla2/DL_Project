import itertools
import os

command = "wget -P {0}/{1:02d} https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_{0}-{1:02d}.parquet"

for y, m in itertools.product(range(2011, 2024), range(1, 13)):
    os.system(command.format(y, m))
